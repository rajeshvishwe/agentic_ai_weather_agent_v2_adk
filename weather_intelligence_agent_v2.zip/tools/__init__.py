"""
Weather Intelligence ADK Tools.
"""